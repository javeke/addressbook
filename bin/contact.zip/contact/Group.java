package contact;

public class Group {

}
