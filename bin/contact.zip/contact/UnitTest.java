package contact;

import java.util.ArrayList;

public class UnitTest {

	public static void main(String[] args) {
		ArrayList<Contact> addressBook= new ArrayList<Contact>();
		
		Contact contact0 = new Contact("Javier","Bryan","Male",19991112l);
		Contact contact1 = new Contact("Anthony","Bryan","Male",19951019);
		Contact contact2 = new Contact("Tashieka","Hart","Female",19990624);
				
		contact0.setAlias("Javy");
		contact0.setAddress("26 Ashley Hall; Waterlane P.O.;Clarendon; Jamaica;");
		
		contact1.setAlias("Junior");
		contact1.setAddress("26 Ashley Hall; Waterlane P.O.;Clarendon; Jamaica;");
		
		contact2.setAlias("Tash");
		contact2.setAddress("517 Mocha Avenue; Old Harbor P.A.; St.Catherine;Jamaica;");
		
		addressBook.add(contact0);
		addressBook.add(contact1);
		addressBook.add(contact2);
		
		for (Contact contact:addressBook) {
			System.out.println(getGender(contact));
		}
	}
	
	public static Gender getGender(Person p) {
		return p.getGender();
	}
}
