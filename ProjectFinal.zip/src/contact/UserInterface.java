package contact;

public class UserInterface {
	
	public static void main(String args[]) {
		
	}
}
