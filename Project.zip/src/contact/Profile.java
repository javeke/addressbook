package contact;

public class Profile {

}
