package contact;

/**
 * 
 * @author Javier Bryan 620119423 
 * @version 1.0
 *
 */
public enum Gender {
	MALE,FEMALE
}
